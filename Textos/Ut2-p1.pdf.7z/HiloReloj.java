package ut2p1;

public class HiloReloj {
	public static void main(String[] args){
		try{
			for (int i = 0; i<100; i++){

				HiloTic tic = new HiloTic();
				HiloTac tac = new HiloTac();
				tic.start();
				Thread.sleep(1000);
				tac.start();
				Thread.sleep(1000);
			}
		}catch(Exception e){}
	}

}
