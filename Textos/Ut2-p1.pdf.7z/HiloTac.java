package ut2p1;

public class HiloTac extends Thread{
	
	public void run(){
		System.out.println("TAC");
	}

}
