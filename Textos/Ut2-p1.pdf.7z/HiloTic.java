package ut2p1;

public class HiloTic extends Thread{
	
	public void run(){
		System.out.println("TIC");
	}

}
