package ut2p4;

public class Cliente {
	public int[] productos;
	public String nombre;
	
	public Cliente(String nom, int[] pro){
		nombre = nom;
		productos = pro;
	}
	
}
