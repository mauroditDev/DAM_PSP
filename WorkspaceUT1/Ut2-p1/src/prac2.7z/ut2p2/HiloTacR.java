package ut2p2;

public class HiloTacR implements Runnable{
	
	public void run(){
		System.out.println("TAC");
	}

}
