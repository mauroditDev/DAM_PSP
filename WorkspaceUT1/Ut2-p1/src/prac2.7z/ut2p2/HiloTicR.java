package ut2p2;

public class HiloTicR implements Runnable{
	
	public void run(){
		System.out.println("TIC");
	}

}
